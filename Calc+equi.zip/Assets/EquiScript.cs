using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


public class EquiScript : MonoBehaviour
{

    [SerializeField] private TMP_InputField InputField3;
    [SerializeField] private TMP_InputField InputField4;
    [SerializeField] private TMP_Text Text4;

 
    public void ButtonLetsEqui()
    {
        float firstNumber = float.Parse(InputField3.text);
        float secondNumber = float.Parse(InputField4.text);

        if (firstNumber == secondNumber)
        {
            Text4.text = ("Числа равны!");
        }
        else if (firstNumber > secondNumber)
        {
            Text4.text = ("Первое число больше!");
        }
        else if (firstNumber < secondNumber)
        {
            Text4.text = ("Второе число больше!");
        }
        else
        {
            Text4.text = ("ошибка");
        }
    }

}
