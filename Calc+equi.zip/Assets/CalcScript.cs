using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


public class CalcScript : MonoBehaviour
{

    [SerializeField] private TMP_InputField InputField1;
    [SerializeField] private TMP_InputField InputField2;
    [SerializeField] private TMP_Text Text3;

    public void ButtonPlus()
    {
        float firstNumber = float.Parse(InputField1.text);
        float secondNumber = float.Parse(InputField2.text);

        float result = firstNumber + secondNumber;
        
        Text3.text = $"{result}";
    }


    public void ButtonMinus()
    {
        float firstNumber = float.Parse(InputField1.text);
        float secondNumber = float.Parse(InputField2.text);

        float result = firstNumber - secondNumber;
        
        Text3.text = $"{result}";
    }

    public void ButtonDiv()
    {
        float firstNumber = float.Parse(InputField1.text);
        float secondNumber = float.Parse(InputField2.text);

        float result = firstNumber / secondNumber;
        
        Text3.text = $"{result}";
    }

    public void ButtonMult()
    {
        float firstNumber = float.Parse(InputField1.text);
        float secondNumber = float.Parse(InputField2.text);

        float result = firstNumber * secondNumber;
        
        Text3.text = $"{result}";
    }

}
